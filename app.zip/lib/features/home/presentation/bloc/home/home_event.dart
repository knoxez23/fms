part of 'home_bloc.dart';

@freezed
class HomeEvent with _$HomeEvent {
  const factory HomeEvent.load() = LoadHome;
  const factory HomeEvent.refresh() = RefreshHome;
}
